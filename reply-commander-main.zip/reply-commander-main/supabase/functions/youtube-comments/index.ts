import "https://esm.sh/@supabase/functions-js/src/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const GOOGLE_CLIENT_ID = Deno.env.get("GOOGLE_CLIENT_ID");
const GOOGLE_CLIENT_SECRET = Deno.env.get("GOOGLE_CLIENT_SECRET");
const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

async function refreshAccessToken(refreshToken: string): Promise<string | null> {
  try {
    const response = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: GOOGLE_CLIENT_ID!,
        client_secret: GOOGLE_CLIENT_SECRET!,
        refresh_token: refreshToken,
        grant_type: "refresh_token",
      }),
    });

    if (!response.ok) return null;
    
    const tokens = await response.json();
    return tokens.access_token;
  } catch {
    return null;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, videoId, commentId, text, userId } = await req.json();
    const apiKey = Deno.env.get("YOUTUBE_API_KEY");

    if (action === "fetch") {
      if (!apiKey) {
        return new Response(
          JSON.stringify({ error: "YouTube API key not configured" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      console.log(`Fetching comments for video: ${videoId}`);
      
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&videoId=${videoId}&maxResults=100&key=${apiKey}`
      );

      if (!response.ok) {
        const error = await response.text();
        console.error("YouTube API error:", error);
        throw new Error(`YouTube API error: ${response.status}`);
      }

      const data = await response.json();
      
      const comments = data.items?.map((item: any) => ({
        id: item.id,
        author: item.snippet.topLevelComment.snippet.authorDisplayName,
        authorProfileImage: item.snippet.topLevelComment.snippet.authorProfileImageUrl,
        text: item.snippet.topLevelComment.snippet.textDisplay,
        likeCount: item.snippet.topLevelComment.snippet.likeCount,
        publishedAt: item.snippet.topLevelComment.snippet.publishedAt,
      })) || [];

      console.log(`Found ${comments.length} comments`);

      return new Response(
        JSON.stringify({ comments }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (action === "reply") {
      if (!userId) {
        return new Response(
          JSON.stringify({ error: "User ID required for replies" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);

      // Get user's YouTube tokens
      const { data: tokenData, error: tokenError } = await supabase
        .from("youtube_tokens")
        .select("*")
        .eq("user_id", userId)
        .single();

      if (tokenError || !tokenData) {
        return new Response(
          JSON.stringify({ error: "YouTube account not connected. Please connect your YouTube account first." }),
          { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      let accessToken = tokenData.access_token;
      
      // Check if token is expired
      if (new Date(tokenData.expires_at) < new Date()) {
        console.log("Access token expired, refreshing...");
        const newToken = await refreshAccessToken(tokenData.refresh_token);
        
        if (!newToken) {
          return new Response(
            JSON.stringify({ error: "Failed to refresh token. Please reconnect your YouTube account." }),
            { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        accessToken = newToken;
        
        // Update token in database
        await supabase
          .from("youtube_tokens")
          .update({ 
            access_token: newToken, 
            expires_at: new Date(Date.now() + 3600 * 1000).toISOString() 
          })
          .eq("user_id", userId);
      }

      console.log(`Replying to comment: ${commentId}`);

      // Post the reply using YouTube API
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/comments?part=snippet`,
        {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            snippet: {
              parentId: commentId,
              textOriginal: text,
            },
          }),
        }
      );

      if (!response.ok) {
        const error = await response.text();
        console.error("YouTube reply error:", error);
        throw new Error(`Failed to post reply: ${response.status}`);
      }

      const replyData = await response.json();
      console.log("Reply posted successfully:", replyData.id);

      return new Response(
        JSON.stringify({ success: true, replyId: replyData.id }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ error: "Invalid action" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: unknown) {
    console.error("Error:", error);
    const message = error instanceof Error ? error.message : "Unknown error occurred";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
