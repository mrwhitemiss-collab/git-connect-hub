import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { MessageSquare, Zap, Shield, Clock, ArrowRight, Play, Youtube } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-background dark">
      {/* Hero Section */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-background" />
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        
        <nav className="relative z-10 flex items-center justify-between px-6 py-4 max-w-7xl mx-auto">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center glow-sm">
              <Youtube className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold">ReplyBot</span>
          </div>
          <Link to="/auth">
            <Button variant="outline" className="border-border/50 hover:bg-secondary">
              Sign In
            </Button>
          </Link>
        </nav>

        <div className="relative z-10 max-w-7xl mx-auto px-6 pt-20 pb-32">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6 animate-fade-in">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Automate Your YouTube Engagement</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6 animate-slide-up">
              Reply to <span className="text-gradient">Every Comment</span> Automatically
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl animate-slide-up" style={{ animationDelay: "0.1s" }}>
              Boost your YouTube engagement by automatically replying to comments on any video. 
              Save hours of manual work and grow your community faster.
            </p>
            
            <div className="flex flex-wrap gap-4 animate-slide-up" style={{ animationDelay: "0.2s" }}>
              <Link to="/auth">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground glow group">
                  Get Started Free
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="border-border/50">
                <Play className="w-4 h-4 mr-2" />
                Watch Demo
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Everything You Need to <span className="text-gradient">Scale Engagement</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Powerful features designed to help you engage with your audience efficiently and safely.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <FeatureCard
              icon={<MessageSquare className="w-6 h-6" />}
              title="Bulk Reply"
              description="Reply to hundreds of comments with a single click. Your message, every comment."
            />
            <FeatureCard
              icon={<Clock className="w-6 h-6" />}
              title="Smart Delays"
              description="Built-in delays between replies to keep your account safe from spam detection."
            />
            <FeatureCard
              icon={<Shield className="w-6 h-6" />}
              title="Quota Tracking"
              description="Real-time API quota monitoring to ensure you never hit unexpected limits."
            />
            <FeatureCard
              icon={<Zap className="w-6 h-6" />}
              title="Instant Setup"
              description="Connect your Google account and start replying in under 2 minutes."
            />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 px-6 bg-secondary/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              How It Works
            </h2>
            <p className="text-muted-foreground text-lg">
              Three simple steps to automate your YouTube replies
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <StepCard
              number="01"
              title="Connect YouTube"
              description="Sign in with your Google account and grant permission to post comments."
            />
            <StepCard
              number="02"
              title="Paste Video URL"
              description="Enter any YouTube video URL to fetch all its comments instantly."
            />
            <StepCard
              number="03"
              title="Start Replying"
              description="Write your reply, select comments, and let the bot handle the rest."
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="glass rounded-3xl p-12 glow">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Ready to Boost Your Engagement?
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              Join thousands of creators automating their YouTube engagement with ReplyBot.
            </p>
            <Link to="/auth">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground glow">
                Start Free Today
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-border/50">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Youtube className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-semibold">ReplyBot</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © 2026 ReplyBot. Not affiliated with YouTube or Google.
          </p>
        </div>
      </footer>
    </div>
  );
};

const FeatureCard = ({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) => (
  <Card className="glass border-border/50 hover:border-primary/30 transition-colors group">
    <CardContent className="p-6">
      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
        {icon}
      </div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-muted-foreground text-sm">{description}</p>
    </CardContent>
  </Card>
);

const StepCard = ({ number, title, description }: { number: string; title: string; description: string }) => (
  <div className="text-center">
    <div className="text-6xl font-bold text-primary/20 mb-4">{number}</div>
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-muted-foreground">{description}</p>
  </div>
);

export default Index;
