import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  Youtube,
  LogOut,
  Link as LinkIcon,
  MessageSquare,
  Play,
  Pause,
  Square,
  CheckCircle2,
  AlertCircle,
  Loader2,
  RefreshCw,
  Settings,
} from "lucide-react";
import { User } from "@supabase/supabase-js";

interface Comment {
  id: string;
  author: string;
  authorProfileImage: string;
  text: string;
  likeCount: number;
  publishedAt: string;
  selected: boolean;
  replied: boolean;
}

const Dashboard = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [videoUrl, setVideoUrl] = useState("");
  const [replyMessage, setReplyMessage] = useState("");
  const [comments, setComments] = useState<Comment[]>([]);
  const [fetchingComments, setFetchingComments] = useState(false);
  const [isReplying, setIsReplying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const [repliedCount, setRepliedCount] = useState(0);
  const [youtubeConnected, setYoutubeConnected] = useState(false);
  const [connectingYoutube, setConnectingYoutube] = useState(false);
  const [delaySeconds, setDelaySeconds] = useState(7);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/auth");
        return;
      }
      setUser(session.user);
      setLoading(false);
      
      // Check YouTube connection status
      checkYoutubeConnection(session.user.id);
    };

    checkAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) {
        navigate("/auth");
      } else {
        setUser(session.user);
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  // Handle OAuth callback
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get("code");
    
    if (code && user) {
      handleOAuthCallback(code);
    }
  }, [user]);

  const checkYoutubeConnection = async (userId: string) => {
    try {
      const { data } = await supabase.functions.invoke("youtube-oauth", {
        body: { action: "checkConnection", userId },
      });
      setYoutubeConnected(data?.connected || false);
    } catch (error) {
      console.error("Error checking YouTube connection:", error);
    }
  };

  const handleOAuthCallback = async (code: string) => {
    if (!user) return;
    
    setConnectingYoutube(true);
    try {
      const redirectUri = `${window.location.origin}/dashboard`;
      
      const { data, error } = await supabase.functions.invoke("youtube-oauth", {
        body: { 
          action: "exchangeCode", 
          code, 
          redirectUri,
          userId: user.id 
        },
      });

      if (error) throw error;

      // Clear the code from URL
      window.history.replaceState({}, document.title, "/dashboard");
      
      setYoutubeConnected(true);
      toast({
        title: "YouTube Connected!",
        description: "You can now reply to comments",
      });
    } catch (error: any) {
      toast({
        title: "Connection Failed",
        description: error.message || "Could not connect YouTube account",
        variant: "destructive",
      });
    } finally {
      setConnectingYoutube(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  const connectYouTube = async () => {
    if (!user) return;
    
    setConnectingYoutube(true);
    try {
      const redirectUri = `${window.location.origin}/dashboard`;
      
      const { data, error } = await supabase.functions.invoke("youtube-oauth", {
        body: { action: "getAuthUrl", redirectUri },
      });

      if (error) throw error;
      
      // Redirect to Google OAuth
      window.location.href = data.authUrl;
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Could not initiate YouTube connection",
        variant: "destructive",
      });
      setConnectingYoutube(false);
    }
  };

  const disconnectYouTube = async () => {
    if (!user) return;
    
    try {
      const { error } = await supabase.functions.invoke("youtube-oauth", {
        body: { action: "disconnect", userId: user.id },
      });

      if (error) throw error;
      
      setYoutubeConnected(false);
      toast({
        title: "Disconnected",
        description: "YouTube account has been disconnected",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Could not disconnect YouTube account",
        variant: "destructive",
      });
    }
  };

  const extractVideoId = (url: string): string | null => {
    const patterns = [
      /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
      /youtube\.com\/shorts\/([^&\n?#]+)/,
    ];
    
    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) return match[1];
    }
    return null;
  };

  const fetchComments = async () => {
    const videoId = extractVideoId(videoUrl);
    if (!videoId) {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid YouTube video URL",
        variant: "destructive",
      });
      return;
    }

    setFetchingComments(true);
    try {
      const { data, error } = await supabase.functions.invoke("youtube-comments", {
        body: { action: "fetch", videoId },
      });

      if (error) throw error;

      const formattedComments: Comment[] = data.comments.map((c: any) => ({
        id: c.id,
        author: c.author,
        authorProfileImage: c.authorProfileImage,
        text: c.text,
        likeCount: c.likeCount,
        publishedAt: c.publishedAt,
        selected: true,
        replied: false,
      }));

      setComments(formattedComments);
      toast({
        title: "Comments loaded!",
        description: `Found ${formattedComments.length} comments on this video`,
      });
    } catch (error: any) {
      toast({
        title: "Error fetching comments",
        description: error.message || "Could not fetch comments",
        variant: "destructive",
      });
    } finally {
      setFetchingComments(false);
    }
  };

  const toggleSelectAll = () => {
    const allSelected = comments.every((c) => c.selected);
    setComments(comments.map((c) => ({ ...c, selected: !allSelected })));
  };

  const toggleComment = (id: string) => {
    setComments(comments.map((c) => 
      c.id === id ? { ...c, selected: !c.selected } : c
    ));
  };

  const startReplying = async () => {
    if (!replyMessage.trim()) {
      toast({
        title: "Reply message required",
        description: "Please enter a reply message",
        variant: "destructive",
      });
      return;
    }

    const selectedComments = comments.filter((c) => c.selected && !c.replied);
    if (selectedComments.length === 0) {
      toast({
        title: "No comments selected",
        description: "Please select at least one comment to reply to",
        variant: "destructive",
      });
      return;
    }

    setIsReplying(true);
    setIsPaused(false);
    setRepliedCount(0);
    setProgress(0);

    for (let i = 0; i < selectedComments.length; i++) {
      if (!isReplying) break;
      
      while (isPaused) {
        await new Promise((resolve) => setTimeout(resolve, 100));
      }

      const comment = selectedComments[i];
      
      try {
        const { data, error } = await supabase.functions.invoke("youtube-comments", {
          body: { 
            action: "reply", 
            commentId: comment.id, 
            text: replyMessage,
            userId: user?.id 
          },
        });

        if (error) throw error;
        if (data?.error) throw new Error(data.error);

        setComments((prev) =>
          prev.map((c) => (c.id === comment.id ? { ...c, replied: true } : c))
        );
        setRepliedCount((prev) => prev + 1);
      } catch (error: any) {
        console.error("Error replying to comment:", error);
      }

      setProgress(((i + 1) / selectedComments.length) * 100);

      if (i < selectedComments.length - 1) {
        await new Promise((resolve) => setTimeout(resolve, delaySeconds * 1000));
      }
    }

    setIsReplying(false);
    toast({
      title: "Replying complete!",
      description: `Successfully replied to ${repliedCount} comments`,
    });
  };

  const pauseReplying = () => setIsPaused(true);
  const resumeReplying = () => setIsPaused(false);
  const stopReplying = () => {
    setIsReplying(false);
    setIsPaused(false);
  };

  const selectedCount = comments.filter((c) => c.selected).length;
  const repliedTotal = comments.filter((c) => c.replied).length;

  if (loading) {
    return (
      <div className="min-h-screen bg-background dark flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background dark">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center glow-sm">
              <Youtube className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold">ReplyBot</span>
          </div>
          
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground hidden md:block">
              {user?.email}
            </span>
            <Button variant="ghost" size="icon" onClick={handleSignOut}>
              <LogOut className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* YouTube Connection Status */}
        {!youtubeConnected && (
          <Card className="glass border-warning/50 mb-8">
            <CardContent className="p-6 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center">
                  <AlertCircle className="w-6 h-6 text-warning" />
                </div>
                <div>
                  <h3 className="font-semibold">Connect YouTube Account</h3>
                  <p className="text-sm text-muted-foreground">
                    You need to connect your YouTube account to post replies
                  </p>
                </div>
              </div>
              <Button 
                onClick={connectYouTube} 
                className="bg-youtube hover:bg-youtube/90"
                disabled={connectingYoutube}
              >
                {connectingYoutube ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : null}
                Connect YouTube
              </Button>
            </CardContent>
          </Card>
        )}

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Panel */}
          <div className="lg:col-span-2 space-y-6">
            {/* Video Input */}
            <Card className="glass border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LinkIcon className="w-5 h-5 text-primary" />
                  Video URL
                </CardTitle>
                <CardDescription>
                  Enter a YouTube video URL to fetch its comments
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-3">
                  <Input
                    placeholder="https://youtube.com/watch?v=..."
                    value={videoUrl}
                    onChange={(e) => setVideoUrl(e.target.value)}
                    className="flex-1 bg-secondary/50 border-border/50"
                  />
                  <Button
                    onClick={fetchComments}
                    disabled={fetchingComments || !videoUrl}
                    className="bg-primary hover:bg-primary/90"
                  >
                    {fetchingComments ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <RefreshCw className="w-4 h-4" />
                    )}
                    <span className="ml-2">Fetch</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Reply Message */}
            <Card className="glass border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-primary" />
                  Reply Message
                </CardTitle>
                <CardDescription>
                  This message will be posted as a reply to selected comments
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  placeholder="Type your reply message here..."
                  value={replyMessage}
                  onChange={(e) => setReplyMessage(e.target.value)}
                  className="min-h-[120px] bg-secondary/50 border-border/50"
                />
              </CardContent>
            </Card>

            {/* Comments List */}
            {comments.length > 0 && (
              <Card className="glass border-border/50">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Comments ({comments.length})</CardTitle>
                      <CardDescription>
                        {selectedCount} selected · {repliedTotal} replied
                      </CardDescription>
                    </div>
                    <Button variant="outline" size="sm" onClick={toggleSelectAll}>
                      {comments.every((c) => c.selected) ? "Deselect All" : "Select All"}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                    {comments.map((comment) => (
                      <div
                        key={comment.id}
                        className={`flex items-start gap-3 p-3 rounded-lg transition-colors ${
                          comment.replied 
                            ? "bg-success/10 border border-success/20" 
                            : "bg-secondary/30 hover:bg-secondary/50"
                        }`}
                      >
                        <Checkbox
                          checked={comment.selected}
                          onCheckedChange={() => toggleComment(comment.id)}
                          disabled={comment.replied}
                        />
                        <img
                          src={comment.authorProfileImage}
                          alt={comment.author}
                          className="w-8 h-8 rounded-full"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-sm">{comment.author}</span>
                            {comment.replied && (
                              <Badge variant="secondary" className="bg-success/20 text-success text-xs">
                                <CheckCircle2 className="w-3 h-3 mr-1" />
                                Replied
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {comment.text}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Settings */}
            <Card className="glass border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-primary" />
                  Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Delay between replies (seconds)
                  </label>
                  <Input
                    type="number"
                    min={3}
                    max={30}
                    value={delaySeconds}
                    onChange={(e) => setDelaySeconds(Number(e.target.value))}
                    className="bg-secondary/50 border-border/50"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Recommended: 5-10 seconds to avoid spam detection
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <Card className="glass border-border/50">
              <CardHeader>
                <CardTitle>Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {isReplying && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Progress</span>
                      <span className="text-muted-foreground">
                        {repliedCount} / {selectedCount}
                      </span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                )}

                <div className="flex flex-col gap-2">
                  {!isReplying ? (
                    <Button
                      onClick={startReplying}
                      disabled={selectedCount === 0 || !replyMessage}
                      className="w-full bg-primary hover:bg-primary/90 glow"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Start Replying ({selectedCount})
                    </Button>
                  ) : (
                    <>
                      <Button
                        onClick={isPaused ? resumeReplying : pauseReplying}
                        variant="outline"
                        className="w-full"
                      >
                        {isPaused ? (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            Resume
                          </>
                        ) : (
                          <>
                            <Pause className="w-4 h-4 mr-2" />
                            Pause
                          </>
                        )}
                      </Button>
                      <Button
                        onClick={stopReplying}
                        variant="destructive"
                        className="w-full"
                      >
                        <Square className="w-4 h-4 mr-2" />
                        Stop
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quota Info */}
            <Card className="glass border-border/50">
              <CardHeader>
                <CardTitle className="text-sm">API Quota</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">
                  YouTube API has a daily limit of ~10,000 units. 
                  Each reply costs ~50 units, allowing approximately 200 replies per day.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
